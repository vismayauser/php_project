<?php include("header.php"); ?>

<?php
if(isset($_POST["Submit"])){
    $upload = 0;
    $target_dir = "uploads/products/";
    $target_file = $target_dir . basename($_FILES["pro_image"]["name"]);
    $uploadOk = 1;
    $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));

    $check = getimagesize($_FILES["pro_image"]["tmp_name"]);
    if($check !== false) {
        echo "File is an image - " . $check["mime"] . ".";
        $uploadOk = 1;
    } else {
        echo "File is not an image.";
        $uploadOk = 0;
    }
    if(file_exists($target_file)){
        echo "Sorry, file already exists.";
        $uploadOk = 0;
    }
    if($_FILES["pro_image"]["size"] > 500000) {
        echo "Sorry, your file is too large.";
        $upload = 0;
    }
    if($imageFileType !="jpg" && $imageFileType !="png" && $imageFileType !=="jpeg" && $imageFileType !== "gif" && $imageFileType !== "webp"){
        echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
        $uploadOk = 0;
    }

    if($uploadOk == 0) {
        echo "Sorry, your file was not uploaded.";
    } else {
        if(move_uploaded_file($_FILES["pro_image"]["tmp_name"], $target_file)) {
            echo "The file" . htmlspecialchars(basename($_FILES["pro_image"]["name"])). " has been uploaded.";
            $uploaded = 1;
        } else {
            echo "Sorry, there was an error uploading your file.";
            $uploaded = 0;
        }
    }
    if($uploaded==1){
        $pro_name = $_POST["pro_name"];
        $pro_price = $_POST["pro_price"];
        $cat_id = $_POST["cat_id"];
        $pro_desc = $_POST["pro_desc"];
        $pro_image = $target_file;
        $sql = "INSERT INTO products (id, pro_name, pro_image, pro_price, cat_id, pro_desc)
        VALUES ('', '$pro_name', '$pro_image', '$pro_price', '$cat_id','$pro_desc')";
        if($conn->query($sql) === TRUE) {
            echo "New product added successfully";
        } else {
            echo "Error:" . $sql . "<br>" . $conn->error;
        }

    }
}
?>
<div class="container mt-3">
    <div class=row>
        <div class="col-sm-4">
            <h2>Add Products</h2>
            <form action="addproducts.php" method="post" enctype="multipart/form-data">
                    <div class="mb-3 mt-3">
                        <label for="pro_name">product name:</label>
                        <input type="text" class="form-control" id="pro_name" placeholder="Enter product name"  name=" pro_name">
                    </div>
                    <div class="mb-3 mt-3">
                        <label for="pro_image">product image:</label>
                        <input type="file" class="form-control" id="pro_image" name="pro_image">
                    </div>
                    <div class="mb-3 mt-3">
                        <label for="pro_price">product price:</lablel>
                        <input type="text" class="form-control" id="pro_price" paceholder="Enter price" name="pro_price">
                    </div>
                    
                    <div class="mb-3 mt-3">
                        <label for="cat_id">product category:</lablel>
                        <select class="form-control" id="cat_id" name="cat_id">

                        <?php
                        $sql = "SELECT * FROM categories";
                        $result = $conn->query($sql);
                        if($result->num_rows > 0) {
                            while($row =$result->fetch_assoc()){
                                $id = $row["id"];
                                $cat_name = $row["cat_name"];
                                echo "<option value='$id'>$cat_name</option>";
                            }
                        }
                        $conn->close();
                        ?>
                        </select>
                    </div>
                    <div class="mb-3 mt-3">
                        <label for="pro_desc">Descreption:</lablel>
                        <input type="text" class="form-control" id="pro_desc" paceholder="Enter descreption" name="pro_desc">
                    </div>
                    <button type="Submit" class="btn btn-primary" name="Submit">Submit</button>
            </form>
        </div>
    </div>
</div>
</body>
</html>