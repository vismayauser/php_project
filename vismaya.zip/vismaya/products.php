<?php include("header.php");
if(isset($_GET["pid"])){
    if(!isset($_SESSION["user"])){
        header("Location: login.php");
    }
    $pid = $_GET["pid"];
    $sql = "SELECT * FROM products WHERE id = '$pid' ";
    $result = $conn->query($sql);
    if($result->num_rows > 0) {
        while($row = $result->fetch_assoc()){
            $cart_user = $_SESSION["user"];
            $prod_id = $row["id"];
            $prod_name = $row["pro_name"];
            $prod_price = $row["pro_price"];
            $prod_image = $row["pro_image"];
            $prod_qty = 1;
            $prod_amount = $row["pro_price"];
            $sql = "INSERT INTO cart (id, cart_user, prod_id, prod_name, prod_price, prod_image, prod_qty, prod_amount)
            VALUES ('', '$cart_user', '$prod_id', '$prod_name', '$prod_price', '$prod_image', '$prod_qty', '$prod_amount')";
            if($conn->query($sql) === TRUE){
                echo "Product added to cart successfully";
            } else {
                echo "Error:" . $sql . "<br>" . $conn->error;
            }
        }
    }
}
?>
<div class="container mt-5">
    <h1 class="display-2 text-center mb-5">Products</h1>
    <div class="row">
    <?php
    if(isset($_GET["cid"])){
        $cid = $_GET["cid"];
        $sql = "SELECT * FROM products WHERE cat_id = '$cid' ";
    } else {
        $sql = "SELECT * FROM products";
    }
     $result = $conn->query($sql);
     if($result->num_rows > 0){
          while($row = $result->fetch_assoc()) { ?>
        <div class="col-sm-3 text-center">
             <img src=" <?php echo $row["pro_image"] ?>" alt="" class="w-100">
             <h4><?php echo $row["pro_name"]; ?></h4>
            <p>Rs. <?php echo $row["pro_price"] ?></p>  
          <a href="products.php?pid=<?php echo $row["id"] ?>" class="btn btn-primary">Add to cart</a>  
        </div>
     <?php }
 } else {
        echo "0 results";
     }
     $conn->close();
    ?>
    </div>
</div>
     </body>
    </html> 
