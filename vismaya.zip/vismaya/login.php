<?php include("header.php");?>
<?php
if(isset($_POST['log_username'])){
    $loguser = $_POST['log_username'];
    $logpswd = $_POST['log_password'];
    $sql = "SELECT * FROM `registration` WHERE `registration_username` = '$loguser' AND `registration_password` = '$logpswd'";
    $result = $conn->query($sql);
    if($result->num_rows>0){
        $_SESSION['user'] = $loguser;
        header("Location: account.php");
    }
    else{
        echo "Username or password is not found";
    }
}
?>
<section class="logsec">
    <div class="container">
        <div class="row">
            <div class="col-6 mx-auto">
                <div class="logbox">
                <h1>Login</h1>
                    <form action="login.php" method="post">
                    <div class="mb-3 mt-3">
                        <label for="username" class="form-label">username:</label>
                        <input type="text" class="form-control" id="username" placeholder="Enter username" name="log_username">
                    </div>
                    <div class="mb-3">
                        <label for="password" class="form-label">Password:</label>
                        <input type="password" class="form-control" id="password" placeholder="Enter password" name="log_password">
                    </div>
                    <button type="submit" class="btn btn-primary">Submit</button>
                </form>
                </div>
            </div>
        </div>    
    </div>   
</section>    
</body>
</html>              