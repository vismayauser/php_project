<?php include("header.php");

if(!isset($_SESSION["user"])){
    header("Location: login.php");
}else{
    $user = $_SESSION["user"];
}
$co=0;
if(isset($_POST["address"])){
    $dlv_adrs=$_POST["address"];
    $pay_type=$_POST["payment_type"];
    $sql = "UPDATE orders SET dlv_adrs='$dlv_adrs', pay_type='$pay_type' WHERE order_user='$user'";
    if ($conn->query($sql) === TRUE) {
    echo "Record updated successfully";
    } else {
    echo "Error updating record: " . $conn->error;
    }
    $co=1;
} else{

    // delete previous checkout data
    $sql = "DELETE FROM orders WHERE order_user='$user' AND order_status=0";
    $conn->query($sql);          

    // insert new data
    $sql = "INSERT INTO `orders`( `order_user`, `prod_id`, `prod_name`, `prod_price`, `prod_image`, `prod_qty`, `prod_amount`) 
    SELECT `cart_user`, `prod_id`, `prod_name`, `prod_price`, `prod_image`, `prod_qty`, `prod_amount`
    FROM cart WHERE cart_user = '$user'";

    if ($conn->query($sql) === TRUE) {
        echo "Data copied successfully!";
    } else {
        echo "Error copying data: " . $conn->error;
    }
}
?>
<h1 style="text-align: center;
 border: 2px solid black;
  outline-style: solid;
  outline-color: black;
  outline-width: thin;" class="bg-info" >Your checkout page</h1>
<style>
    .box1{
        text-align: right;
    }
</style>
<br><br>
<div class="container mt-3">         
  <table class="table">
    <thead>
      <tr>
        <th>Item</th>
        <th>Price</th>
        <th>Quantity</th>
        <th>Total</th>
      </tr>
    </thead>
    <tbody>

<?php
$sql = "SELECT * FROM orders WHERE order_user='$user' AND order_status";
 $result = $conn->query($sql);
     $tot = 0;
      if($result->num_rows > 0){
         while($row = $result->fetch_assoc()) {
            $id = $row["id"];
            $tot += $row["prod_amount"];
            ?>
      <tr>
        <td> <img src="<?php echo $row["prod_image"] ?>" alt="" width="60px" height="60px"> <?php echo $row["prod_name"] ?></td>
        <td><?php echo $row["prod_price"] ?></td>
        <td>
        <?php echo $row["prod_qty"] ?>
    </td>
        <td><?php echo $row["prod_amount"] ?></td>
      </tr>
       <?php } 
} else {
    echo "0 results";
}
$conn->close();
?>
    </tbody>
  </table>
</div>
     <div class="container">
        <div class="row">
            <div class="box1">
                <div class="col-sm-7">
                <style>
        fieldset {
            margin-bottom: 20px;
            padding: 10px;
        }
        legend {
            font-weight: bold;
        }
        label {
            display: block;
            margin-bottom: 5px;
        }
        textarea {
            width: 100%;
            height: 100px;
            padding: 10px;
            box-sizing: border-box;
        }
        button {
            padding: 10px 20px;
            font-size: 16px;
            cursor: pointer;
        }
    </style>
             <?php if($co==0){ ?>
            <h3 style="text-align: center;
             border: 2px solid black;
  outline-style: solid;
  outline-color: black;
  outline-width: thin;" class="text-bg-success">Delivery and Payment Form</h3>
    <form action="checkout.php" method="post">

        <!-- Delivery Address Section -->
        <fieldset>
            <legend>Delivery Address</legend>
            <label for="address">Address:</label>
            <textarea id="address" name="address" placeholder="Enter your delivery address here" required></textarea>
        </fieldset>
        <br>
        <!-- Payment Type Section -->
        <fieldset>
            <legend>Payment Type</legend>
            <label for="payment-cod">Cash on Delivery (COD):</label>
            <input type="radio" id="payment-cod" name="payment_type" value="cod" required>
            <br>
            <label for="payment-online">Online Payment:</label>
            <input type="radio" id="payment-online" name="payment_type" value="online" required>
        </fieldset>
        <br>
        <!-- Submit Button -->
        <button type="submit">Submit</button>
    </form>
    <?php }else{ ?>
                    <h6>Subtotal: <?php echo $tot; ?></h6>
                    <?php $tax =  $tot * 18/100; ?>
                    <h6>Sales tax:<?php echo $tax;?></h6>
                    <h6>Coupon code: XLHJ44</h6>
                    <?php $gtot =  $tot + $tax; ?>
                    <h6>Grand total:<?php echo $gtot; ?></h6>
                    <a href="conformorder.php" class="btn btn-success">Conform order</a>
                    <?php } ?>
                </div>
            </div>
        </div>
    </div>
<br> 
   

    
   