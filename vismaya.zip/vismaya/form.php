<?php
$servername = "localhost";
$username = "root";
$password = "";
$db_name = "vismaya_db";

// Create connection
$conn = new mysqli($servername, $username, $password, $db_name);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
// echo "Connected successfully";


if(isset($_POST['con_name'])){
    $cname =  $_POST['con_name'];
    $cemail =  $_POST['con_email'];
    $cmessage = $_POST['con_message'];
    
    $sql = "INSERT INTO `contact`(`contact_id`, `contact_name`, `contact_email`, `contact_msg`) VALUES (NULL,'$cname','$cemail','$cmessage')";
    if ($conn->query($sql) === TRUE){
        echo "Contact Added Successfully";
    }
    else{
        echo "Error Adding Contact Details";
    }
    $conn->close();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    
     <form action="" method="post">
        <label for="">Enter your name</label>
        <input type="text" name="con_name">
        <br><br>
        <label for="">Enter your email</label>
        <input type="email" name="con_email">
        <br><br> 
        <label for="">Enter your msg</label>
        <textarea name="con_message" rows="5" cols="50"></textarea>
        <br><br>
        <button type="submit">Submit</button>           
     </form>  
</body>
</html>