<?php include("header.php") ;

if(!isset($_SESSION["user"])){
    header("Location: login.php");
}else{
    $user = $_SESSION["user"];
}

if(isset($_GET['del'])){
    $cid = $_GET['cid'];
    $sql = "DELETE FROM cart WHERE id = '$cid'";
    if ($conn->query($sql) === TRUE) {
        echo "Item deleted successfully";
      } else {
        echo "Error deleting record: " . $conn->error;
      }
}

if(isset($_GET['q'])){
    $q= $_GET['q'];
    $cid = $_GET['cid'];

    if($q=='inc'){
        $sql = "UPDATE cart SET prod_qty = prod_qty+1, prod_amount = prod_qty*prod_price WHERE id='$cid'";
    }else if($q=='dec'){
        $sql = "UPDATE cart SET prod_qty = CASE 
                  WHEN prod_qty > 1 THEN prod_qty - 1 
                  ELSE prod_qty 
                END, prod_amount = prod_qty * prod_price WHERE id = '$cid';";
    }
    $conn->query($sql);
}
?>
<br>

<h1 class="bg-warning" style="text-align: center;
 border: 2px solid black;
  outline-style: solid;
  outline-color: black;
  outline-width: thin;">Your cart items</h1>
<br>
<style>
    .box1{
        position: absolute;
        right:300px;
        top: 500px;
    }
</style>
<br><br>

<div class="container mt-3">         
  <table class="table">
    <thead>
      <tr>
        <th>Item</th>
        <th>Price</th>
        <th>Quantity</th>
        <th>Total</th>
      </tr>
    </thead>
    <tbody>

<?php
$sql = "SELECT * FROM cart WHERE cart_user='$user'";
$result = $conn->query($sql);
    $tot = 0;
     if($result->num_rows > 0){
          while($row = $result->fetch_assoc()) { 
            $id = $row["id"];
            $tot += $row["prod_amount"];
            ?>
      <tr>
        <td> <img src="<?php echo $row["prod_image"] ?>" alt="" width="60px" height="60px"> <?php echo $row["prod_name"] ?></td>
        <td><?php echo $row["prod_price"] ?></td>
        <td>
      <a href="cart.php?q=dec&cid=<?php echo $id; ?>" class="btn btn-danger">-</a>
        <?php echo $row["prod_qty"] ?>
        <a href="cart.php?q=inc&cid=<?php echo $id; ?>" class="btn btn-success">+</a>
    </td>
        <td><?php echo $row["prod_amount"] ?>
        <br>
    </td>
    <td>
        <a href="cart.php?del=1&cid=<?php echo $id; ?>" class="btn btn-danger">delete</a>
    </td>
      </tr>
      <?php }
} else {
    echo "0 results";
}
$conn->close();
?>
    </tbody>
  </table>
</div>

  <div class="box1">
    <h6>Subtotal: <?php echo $tot; ?></h6>
    <?php $tax = $tot * 18/100; ?>
    <h6>Sales tax: <?php echo $tax;?> </h6>
    <h6>Coupon code: XLHJ44</h6>
    <?php $gtot = $tot + $tax; ?>
    <h6>Grand total: <?php echo $gtot; ?></h6>
    <a href="checkout.php" class=" btn btn-primary">Checkout</a> 
  </div>    