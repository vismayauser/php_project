-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 16, 2024 at 10:53 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `vismaya_db1`
--

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `id` int(11) NOT NULL,
  `cart_user` varchar(100) NOT NULL,
  `prod_id` int(11) NOT NULL,
  `prod_name` varchar(100) NOT NULL,
  `prod_price` double NOT NULL,
  `prod_image` text NOT NULL,
  `prod_qty` int(11) NOT NULL,
  `prod_amount` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(11) NOT NULL,
  `cat_name` varchar(100) NOT NULL,
  `cat_image` text NOT NULL,
  `cat_desc` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `cat_name`, `cat_image`, `cat_desc`) VALUES
(2, 'Home appliances', 'uploads/categories/Homeappliances.jpg', 'Nothing'),
(3, 'Electronics', 'uploads/categories/electronics.jpg', 'Nothing'),
(4, 'stationery items', 'uploads/categories/stationeryitems.jpg', 'Nothing'),
(9, 'Food items', 'uploads/categories/fooditems.jpg', 'Nothing');

-- --------------------------------------------------------

--
-- Table structure for table `contact1`
--

CREATE TABLE `contact1` (
  `contact1_id` int(11) NOT NULL,
  `contact1_name` varchar(250) NOT NULL,
  `contact1_email` varchar(250) NOT NULL,
  `contact1_msg` varchar(260) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `contact1`
--

INSERT INTO `contact1` (`contact1_id`, `contact1_name`, `contact1_email`, `contact1_msg`) VALUES
(2, 'Vismaya.R', 'vismaya@gmail.com', 'How are you..?'),
(3, 'vismaya', 'vismaya@gmail.com', 'Hello...'),
(5, 'vismaya', 'vismaya@gmail.com', 'hiiiiii');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(20) NOT NULL,
  `order_user` varchar(100) NOT NULL,
  `prod_id` int(20) NOT NULL,
  `prod_name` varchar(200) NOT NULL,
  `prod_price` double NOT NULL,
  `prod_image` text NOT NULL,
  `prod_qty` int(20) NOT NULL,
  `prod_amount` double NOT NULL,
  `dlv_adrs` text NOT NULL,
  `pay_type` varchar(100) NOT NULL,
  `order_status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `order_user`, `prod_id`, `prod_name`, `prod_price`, `prod_image`, `prod_qty`, `prod_amount`, `dlv_adrs`, `pay_type`, `order_status`) VALUES
(147, 'vismaya', 6, 'pencil', 50, 'uploads/products/pencil.jpg', 1, 50, 'Palakkad', 'cod', 1),
(148, 'vismaya', 7, 'Television', 3000, 'uploads/products/television.jpg', 1, 3000, 'Palakkad', 'cod', 1),
(181, 'vismaya', 8, 'Refrigerator', 5000, 'uploads/products/Refrigerator.png', 1, 5000, 'Palakkad', 'cod', 1),
(199, 'vismaya', 5, 'pen', 300, 'uploads/products/pen.webp', 1, 300, 'Palakkad', 'cod', 1);

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(50) NOT NULL,
  `pro_name` varchar(100) NOT NULL,
  `pro_image` text NOT NULL,
  `pro_price` double NOT NULL,
  `cat_id` int(11) NOT NULL,
  `pro_desc` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `pro_name`, `pro_image`, `pro_price`, `cat_id`, `pro_desc`) VALUES
(5, 'pen', 'uploads/products/pen.webp', 300, 2, 'Nothing'),
(6, 'pencil', 'uploads/products/pencil.jpg', 50, 4, 'Nothing'),
(7, 'Television', 'uploads/products/television.jpg', 3000, 2, 'Nothing'),
(8, 'Refrigerator', 'uploads/products/Refrigerator.png', 5000, 3, 'Nothing');

-- --------------------------------------------------------

--
-- Table structure for table `registration`
--

CREATE TABLE `registration` (
  `registration_id` int(11) NOT NULL,
  `registration_name` varchar(255) NOT NULL,
  `registration_phonenumber` int(20) NOT NULL,
  `registration_email` varchar(200) NOT NULL,
  `registration_username` varchar(50) NOT NULL,
  `registration_password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `registration`
--

INSERT INTO `registration` (`registration_id`, `registration_name`, `registration_phonenumber`, `registration_email`, `registration_username`, `registration_password`) VALUES
(11, 'Vismaya.R', 2147483647, 'Vismaya1@gmail.com', 'vismaya', '123456'),
(12, 'Vismaya.R', 2147483647, 'Vismaya1@gmail.com', '', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contact1`
--
ALTER TABLE `contact1`
  ADD PRIMARY KEY (`contact1_id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `registration`
--
ALTER TABLE `registration`
  ADD PRIMARY KEY (`registration_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `contact1`
--
ALTER TABLE `contact1`
  MODIFY `contact1_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=201;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `registration`
--
ALTER TABLE `registration`
  MODIFY `registration_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
