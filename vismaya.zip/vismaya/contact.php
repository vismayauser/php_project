<?php include("header.php"); ?>
<?php
if(isset($_POST['con_name'])){
    $cname = $_POST['con_name'];
    $cemail = $_POST['con_email'];
    $cmessage = $_POST['con_message'];

    $sql = "INSERT INTO `contact1`(`contact1_id`, `contact1_name`, `contact1_email`, `contact1_msg`) VALUES (NULL,'$cname','$cemail','$cmessage')";
    if($conn->query($sql) === True){
        echo "Contact added successfully";
    }
    else{
        echo "Error adding contact details";
    }
    $conn->close();
}
?>
<section class="logsec">
    <div class="container">
        <div class="row">
            <div class="col-6 mx-auto">
                <div class="logbox">
                <h1>Contact</h1>
                    <form action="login.php" method="post">
                    <div class="mb-3 mt-3">
                        <label for="username" class="form-label">username:</label>
                        <input type="text" class="form-control" id="name" placeholder="Enter name" name="con_name">
                    </div>
                    <div class="mb-3">
                        <label for="password" class="form-label">Password:</label>
                        <input type="password" class="form-control" id="email" placeholder="Enter email" name="con_email">
                    </div>
                    <div class="mb-3">
                        <label for="password" class="form-label">Password:</label>
                        <input type="password" class="form-control" id="message" placeholder="Enter message" name="con_message">
                    </div>
                    <button type="submit" class="btn btn-primary">Submit</button>
                </form>
                </div>
            </div>
        </div>    
    </div>   
</section>    
</body>
</html>              


    