<?php include("header.php"); 

if(!isset($_SESSION["user"])){
    header("Location: login.php");
}else{
    $user = $_SESSION["user"];
}
?>
<br>
<h1 class="text-bg-primary" style="text-align: center;
 border: 2px solid black;
  outline-style: solid;
  outline-color: black;
  outline-width: thin;">Your order list</h1>
  <br>

<div class="container mt-3">         
  <table class="table">
    <thead>
      <tr>
        <th>Item</th>
        <th>Price</th>
        <th>Quantity</th>
        <th>Total</th>
      </tr>
    </thead>
    <tbody>

<?php
$sql = "SELECT * FROM orders WHERE order_user='$user' AND order_status='1'";
 $result = $conn->query($sql);
     $tot = 0;
      if($result->num_rows > 0){
         while($row = $result->fetch_assoc()) {
            $id = $row["id"];
            $tot += $row["prod_amount"];
           ?>
      <tr>
        <td> <img src="<?php echo $row["prod_image"] ?>" alt="" width="60px" height="60px"> <?php echo $row["prod_name"] ?></td>
        <td><?php echo $row["prod_price"] ?></td>
        <td>
        <?php echo $row["prod_qty"] ?>
    </td>
        <td><?php echo $row["prod_amount"] ?></td>
      </tr>
       <?php } 
} else {
    echo "0 results";
}
$conn->close();
?>
    </tbody>
  </table>
</div>
   