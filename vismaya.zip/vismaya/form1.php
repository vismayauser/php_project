<?php
$servername = "localhost";
$username = "root";
$password = "";
$db_name = "vismaya_db1";

$conn = new mysqli($servername, $username, $password, $db_name);
if($conn->connect_error){
    die("connection failed:".$conn->connect_error);
}
echo "Connected successfully";
if(isset($_POST['con_name'])){
    $cname = $_POST['con_name'];
    $cemail = $_POST['con_email'];
    $cmessage = $_POST['con_message'];

    $sql = "INSERT INTO `contact1`(`contact1_id`, `contact1_name`, `contact1_email`, `contact1_msg`) VALUES (NULL,'$cname','$cemail','$cmessage')";
    if($conn->query($sql) === True){
        echo "Contact added successfully";
    }
    else{
        echo "Error adding contact details";
    }
    $conn->close();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action="" method="post">
        <label for="">Enter your name</label>
        <input type="text" name="con_name">
        <br><br>
        <label for="">Enter your email</label>
        <input type="text" name="con_email">
        <br><br>
        <label for="">Enter your msg</label>
        <textarea name="con_message" rows="5" cols="30"></textarea>
        <br><br>
        <button class="submit">Submit</button>
    </form>

</body>
</html>