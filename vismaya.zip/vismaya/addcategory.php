<?php include("header.php"); ?>

<?php
if(isset($_POST["Submit"])){
    $upload = 0;
    $target_dir = "uploads/categories/";
    $target_file = $target_dir . basename($_FILES["cat_image"]["name"]);
    $uploadOk = 1;
    $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
    $check = getimagesize($_FILES["cat_image"]["tmp_name"]);
    if($check !== false) {
        echo "File is an image - " . $check["mime"] . ".";
        $uploadOk = 1;
    } else {
        echo "File is not an image.";
        $uploadOk = 0;
    }

    if(file_exists($target_file)){
        echo "Sorry, file already exists.";
        $uploadOk = 0;
    }

    if($_FILES["cat_image"]["size"] > 500000) {
        echo "Sorry, your file is too large.";
        $upload = 0;
    }

    if($imageFileType !="jpg" && $imageFileType !="png" && $imageFileType !=="jpeg" && $imageFileType !== "gif" && $imageFileType !== "webp"){
        echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
        $uploadOk = 0;
    }

    if($uploadOk == 0) {
        echo "Sorry, your file was not uploaded.";
    } else {
        if(move_uploaded_file($_FILES["cat_image"]["tmp_name"], $target_file)) {
            echo "The file" . htmlspecialchars(basename($_FILES["cat_image"]["name"])). " has been uploaded.";
            $uploaded = 1;
        } else {
            echo "Sorry, there was an error uploading your file.";
            $uploaded = 0;
        }
    }

    if($uploaded==1){
        $cat_name = $_POST["cat_name"];
        $cat_desc = $_POST["cat_desc"];
        $cat_image = $target_file;
        $sql = "INSERT INTO categories (id, cat_name, cat_image, cat_desc)
        VALUES ('', '$cat_name', '$cat_image', '$cat_desc')";
        if($conn->query($sql) === TRUE) {
            echo "New category added successfully";
        } else {
            echo "Error:" . $sql . "<br>" . $conn->error;
        }
        $conn->close();
    }
}
?>
<div class="container mt-3">
    <div class=row>
        <div class="col-sm-4">
            <h2>Add Category</h2>
            <form action="addcategory.php" method="post" enctype="multipart/form-data">
                    <div class="mb-3 mt-3">
                        <label for="cat_name">Category name:</label>
                        <input type="text" class="form-control" id="cat_name" placeholder="Enter category name"  name=" cat_name">
                    </div>
                    <div class="mb-3 mt-3">
                        <label for="cat_image">category image:</label>
                        <input type="file" class="form-control" id="cat_image" name="cat_image">
                    </div>
                    <div class="mb-3 mt-3">
                        <label for="cat_desc">Descreption:</label>
                        <input type="text" class="form-control" id="cat_desc" placeholder="Enter descreption" name="cat_desc">
                    </div>
                    <button type="Submit" class="btn btn-primary" name="Submit">Submit</button>
            </form>
        </div>
    </div>
</div>
</body>
</html>