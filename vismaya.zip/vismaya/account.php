<?php include("header.php");

if(!isset($_SESSION["user"])){
    header("Location: login.php");
}
?>

<h1>Account</h1>
<p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Quis earum voluptatibus mollitia sed tempore corporis, perferendis consectetur? Beatae assumenda quos excepturi. Nisi, quibusdam inventore! Cumque magnam consequuntur adipisci voluptates nesciunt?Lorem ipsum dolor sit amet consectetur adipisicing elit. Quis earum voluptatibus mollitia sed tempore corporis, perferendis consectetur? Beatae assumenda quos excepturi. Nisi, quibusdam inventore! Cumque magnam consequuntur adipisci voluptates nesciunt?Lorem ipsum dolor sit amet consectetur adipisicing elit. Quis earum voluptatibus mollitia sed tempore corporis, perferendis consectetur? Beatae assumenda quos excepturi. Nisi, quibusdam inventore! Cumque magnam consequuntur adipisci voluptates nesciunt?</p>