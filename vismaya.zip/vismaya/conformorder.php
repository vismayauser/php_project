<?php include("header.php"); 

if(!isset($_SESSION["user"])){
    header("Location: login.php");
}else{
    $user = $_SESSION["user"];
}
?>
 <style>
    .box{
        text-align: center;
        border: 2px solid black;
  outline: #4CAF50 solid 10px;
  margin: auto;  
  padding: 20px;
  
    }
 </style>

<?php
    $sql = "UPDATE orders SET order_status='1' WHERE order_user='$user'";
    if ($conn->query($sql) === TRUE) { ?>
    <br>
    <h1 class="text-muted" style="text-align:center;
    border: 3px solid black;
  outline: #4CAF50 solid 10px;
  margin: auto;  
  padding: 20px;"
  >Your order is conformed</h1>
  <br>
<p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Sunt rerum unde ipsum. Dolore aspernatur dolorem illum tempora necessitatibus veniam excepturi amet nobis mollitia molestias asperiores debitis cumque eius, harum corporis? Sunt rerum unde ipsum.</p>
    <?php } else {
    echo "Error updating record: " . $conn->error;
    }
    ?>

    <a href="orderlist.php" class="btn btn-primary">order list</a>

    