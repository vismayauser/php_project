<?php include("header.php");?>

<?php
if(isset($_POST['reg_name'])){
    $rname = $_POST['reg_name'];
    $rphonenumber = $_POST['reg_phonenumber'];
    $remail = $_POST['reg_email'];
    $rusername = $_POST['reg_username'];
    $rpassword = $_POST['reg_password'];
    

    $sql = "INSERT INTO `registration`(`registration_id`, `registration_name`, `registration_phonenumber`, `registration_email`,`registration_username`, `registration_password`) VALUES (NULL,'$rname','$rphonenumber','$remail','$rusername','$rpassword')";
    if($conn->query($sql) === True){
        echo "Registration added successfully";
    }
    else{
        echo "Error adding registration details";
    }
    $conn->close();
}
?>
    <section class="logsec">
    <div class="container">
        <div class="row">
            <div class="col-6 mx-auto">
                <div class="logbox">
                <h1>Registration</h1>
                    <form action="" method="post">
                    <div class="mb-3 mt-3">
                        <label for="name" class="form-label">name:</label>
                        <input type="text" class="form-control" id="name" placeholder="Enter name"  name=" reg_name">
                    </div>
                    <div class="mb-3 mt-3">
                        <label for="email" class="form-label">email:</label>
                        <input type="email" class="form-control" id="email" placeholder="Enter email" name="reg_email">
                    </div>
                    <div class="mb-3 mt-3">
                        <label for="number" class="form-label">number:</label>
                        <input type="nmber" class="form-control" id="number" placeholder="Enter number" name="reg_phonenumber">
                    </div>
                    <div class="mb-3 mt-3">
                        <label for="username" class="form-label">Username:</label>
                        <input type="text" class="form-control" id="username" placeholder="Enter username" name="reg_username">
                    </div>
                    <div class="mb-3">
                        <label for="password" class="form-label">Password:</label>
                        <input type="password" class="form-control" id="password" placeholder="Enter password" name="reg_password">
                    </div>
                    <button type="submit" class="btn btn-primary">Submit</button>
                </form>
                </div>
            </div>
        </div>
    </div>
</section>
</body>
</html>