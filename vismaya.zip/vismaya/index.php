<?php include("header.php");?>

<div class="container-fluid p-5 bg-primary text-white text-center">
    <h1>My shopping website</h1>
    <p>Resize this responsive page to see the effect!</p>
</div>

<div class="container mt-5">
    <h1 class="display-2 text-center mb-5">Categories</h1>
    <div class="row">
    <?php
    $sql = "SELECT * FROM categories";
    $result = $conn->query($sql);
    if($result->num_rows > 0){
        while($row = $result->fetch_assoc()){ ?>

            <div class="col-sm-3 text-center">
                <a href="products.php?cid=<?php echo $row["id"]?>">
                    <img src="<?php echo $row["cat_image"]?>" alt="" class="w-100">
                    <h4><?php echo $row["cat_name"];?></h4>
                    <p><?php echo $row["cat_desc"]?></p>
                </a>
            </div>
            <?php }

        }else {
            echo "0 results";
    }
    $conn->close();
    ?>
    </div>
</div>
</body>
</html>