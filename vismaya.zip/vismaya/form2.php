<?php
$servername = "localhost";
$username = "root";
$password = "";
$db_name = "vismaya_db1";

$conn = new mysqli($servername, $username, $password, $db_name);
if($conn->connect_error){
    die("connection failed:".$conn->connect_error);
}
echo "Connected successfully";

if(isset($_POST['reg_name'])){
    $rname = $_POST['reg_name'];
    $rphonenumber = $_POST['reg_phonenumber'];
    $remail = $_POST['reg_email'];

    $sql = "INSERT INTO `registration`(`registration_id`, `registration_name`, `registration_phonenumber`, `registration_email`) VALUES (NULL,'$rname','$rphonenumber','$remail')";
    if($conn->query($sql) === True){
        echo "Registration added successfully";
    }
    else{
        echo "Error adding registration details";
    }
    $conn->close();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<form action="" method="post">
        <label for="">Enter your name</label>
        <input type="text" name="reg_name">
        <br><br>
        <label for="">Enter your phone number</label>
        <input type="text" name="reg_phonenumber">
        <br><br>
        <label for="">Enter your email</label>
        <input type="text" name="reg_email">
        <br><br>
        <button class="submit">Submit</button>
    </form>
    
</body>
</html>